package com.example.firebasemessenger

class User {
    var name: String? = null
    var email: String? = null
    var uid: String? = null
    var profileImageUri: String? = null

    constructor(){}

    constructor(name1: String, email1:String, uid1:String, profileImageUri1:String){
        this.name = name1
        this.email = email1
        this.uid = uid1
        this.profileImageUri = profileImageUri1
    }
}