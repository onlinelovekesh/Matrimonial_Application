package com.example.firebasemessenger

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.android.synthetic.main.activity_registration.*
import kotlinx.android.synthetic.main.activity_user_profile.*
import java.util.*

class RegistrationActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var mDbRef: DatabaseReference
    private lateinit var storageReference: StorageReference
    private lateinit var imageUri: Uri

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        supportActionBar?.hide()

        //initialize the FirebaseAuth instance
        auth = FirebaseAuth.getInstance()

        reg_btnRegistration.setOnClickListener {
            var name = findViewById<TextView>(R.id.reg_name).text.toString()
            var email = findViewById<TextView>(R.id.reg_email).text.toString()
            var password = findViewById<TextView>(R.id.reg_password).text.toString()
            var cnfPassword = findViewById<TextView>(R.id.reg_cnf_password).text.toString()
            //var pwdStatus = findViewById<TextView>(R.id.reg_pwdStatus)

            when {
                name.isEmpty() -> Toast.makeText(this, "Please enter your name", Toast.LENGTH_LONG).show()
                email.isEmpty() -> Toast.makeText(this, "Please enter your email", Toast.LENGTH_LONG).show()
                password.isEmpty() -> Toast.makeText(this, "Please enter your password", Toast.LENGTH_LONG).show()
                cnfPassword.isEmpty() -> Toast.makeText(this, "Confirm password field is empty", Toast.LENGTH_LONG).show()
                password != cnfPassword -> Toast.makeText(this, "Password and confirm password are not same", Toast.LENGTH_LONG).show()
                    //pwdStatus.text = "Password and confirm password are not same"
                else ->{
                    signUp(email, password)

                }
            }
        }
        reg_alreadyRegistered.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
        reg_addImage.setOnClickListener {
            startFileChooser()
        }


    }

    private fun signUp(email: String, password:String){

        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener {
            if (it.isSuccessful){

                    uploadPhoto()

            }
        }
            .addOnFailureListener {
            Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun uploadPhoto() {

        if (imageUri!=null){
            val pd = ProgressDialog(this)
            pd.setTitle("Uploading image")
            pd.show()

            //val fileName = UUID.randomUUID().toString() //optional
            val imageRef = FirebaseStorage.getInstance().reference
                .child("Users").child(auth.currentUser?.uid!!).child("profileImage")//.child(fileName)
            imageRef.putFile(imageUri)
                .addOnSuccessListener {p0 ->
                    pd.dismiss()
                    Toast.makeText(this, "Image updated successfully", Toast.LENGTH_LONG).show()

                    //getting path of the image after inserting
                    imageRef.downloadUrl.addOnSuccessListener {
                        addUserToDatabase(it.toString())
                    }

                }
                .addOnFailureListener{p0 ->
                    pd.dismiss()
                    Toast.makeText(this, "Please try again", Toast.LENGTH_LONG).show()
                }
                .addOnProgressListener {p0 ->
                    val progress = (100.0 * p0.bytesTransferred)/p0.totalByteCount
                    pd.setMessage("uploaded ${progress.toInt()}%")

                }
        }
    }

    private fun startFileChooser() {
        var i = Intent()
        i.type = "image/*" + auth.currentUser?.uid
        i.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(i, "Choose Picture"), 111)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 111 && resultCode == Activity.RESULT_OK && data != null){
            imageUri = data.data!!
            var bitmap = MediaStore.Images.Media.getBitmap(contentResolver,imageUri)
            reg_profileImage.setImageBitmap(bitmap)
        }
    }


    private fun addUserToDatabase(profileImageUri: String){
        mDbRef = FirebaseDatabase.getInstance().reference.child("User").child(auth.currentUser?.uid!!)
        val userDetails = User(reg_name.text.toString(),reg_email.text.toString(),auth.currentUser?.uid!!,profileImageUri)
        mDbRef.setValue(userDetails).addOnSuccessListener {

            Toast.makeText(this, "Registration successful", Toast.LENGTH_LONG).show()
            val i = Intent(this, LoginActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(i)
        }

    }
}
